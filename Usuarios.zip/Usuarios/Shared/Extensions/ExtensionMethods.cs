﻿namespace Shared.Extensions
{
    public static class ExtensionMethods
    {
    }
}