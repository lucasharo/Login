﻿namespace Entities.Entities
{
    public class AlteraSenha
    {
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
    }
}
