﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Enums
{
    public enum StatusResponse
    {
        Success = 0,
        BusinessError = 1,
        SystemError = 2
    }
}
