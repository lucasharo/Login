﻿namespace Entities.Settings
{
    public static class Role
    {
        public const string Admin = "Admin";
        public const string User = "User";
        public const string AlterarSenha = "AlterarSenha";
    }
}
