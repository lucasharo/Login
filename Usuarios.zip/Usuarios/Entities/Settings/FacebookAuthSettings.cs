namespace Entities.Settings
{
    public class FacebookAuthSettings
    {
      public string AppId { get; set; }
      public string AppSecret { get; set; }
    }
}